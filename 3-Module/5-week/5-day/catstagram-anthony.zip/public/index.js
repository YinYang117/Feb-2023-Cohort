window.addEventListener("DOMContentLoaded", async () => {
    /* HTML ELEMENT SELECTORS */
    const img = document.getElementById('image');
    const themeBtn = document.getElementById('dark-mode-btn');
    const leftBtn = document.getElementsByClassName('nav-btn-1')[0];
    const rightBtn = document.getElementsByClassName('nav-btn-2')[0];
    const body = document.body;
    const votes = document.getElementsByClassName('votes-count')[0];
    const upvoteBtn = document.getElementById('up-vote');
    const downvoteBtn = document.getElementById('down-vote')
    const submitBtn = document.getElementsByClassName('submit-comment-btn')[0];
    const commentsFeed = document.getElementById('comment-feed-items');
    let commentsArr = document.querySelectorAll('li');
    const inputfield = document.getElementsByClassName('input-box')[0];

    /* GLOBAL VARIABLES */
    const cats = [];
    let darkMode = true
    let curr = cats.length - 1;
    let voteCount = votes.innerText;
    let inputField = '';
    let id = 0;
    /* CLASSES */

    class Cat {
        constructor(id, url, votes, comments = []) {
            this.id = id;
            this.url = url;
            this.votes = votes;
            this.comments = comments
        }
    }


    /* EVENT LISTENERS */


    inputfield.addEventListener('keypress', (e) => {
        inputField += `${e.key}`

    })

    submitBtn.addEventListener('click', (e) => {
        const date = new Date();
        let day = date.getDate();
        let year = date.getFullYear();
        let month = date.getMonth();
        let comment = document.createElement('li');
        let spanText = document.createElement('span');
        let spanTime = document.createElement('span');

        spanText.innerText = inputField
        spanTime.innerText = `${month}/${day}/${year}`
        comment.innerHTML = spanText.innerText + "    " + spanTime.innerText
        comment.className = 'comment-text';
        commentsFeed.appendChild(comment)
        let cat = cats[curr];
        cat.comments.push(comment)
        commentsArr = document.querySelectorAll('li');
        inputfield.value = '';
        inputField = '';
    })

    upvoteBtn.addEventListener('click', (e) => {
        let currentCat = cats[curr];
        currentCat.votes++;
        // // voteCount++;
        votes.innerText = currentCat.votes;
    })

    downvoteBtn.addEventListener('click', (e) => {
        let currentCat = cats[curr];
        currentCat.votes--;
        // voteCount++;
        votes.innerText = currentCat.votes;
    })


    leftBtn.addEventListener('click', (e) => {
        if (curr > 0) {
            curr--;
            img.src = cats[curr].url;
            votes.innerText = cats[curr].votes
            inputfield.value = ''
            loadComments(cats[curr])
        } else if (curr === 0) {
            img.src = cats[curr].url;
            votes.innerText = cats[curr].votes
        }
    })

    rightBtn.addEventListener('click', (e) => {
        curr++;
        if (curr > cats.length - 1) {
            inputfield.value = ''
            getCat();
        } else {
            img.src = cats[curr].url;
            votes.innerText = cats[curr].votes
            // clearFeed()
            inputfield.value = ''
            loadComments(cats[curr])
        }
    })

    themeBtn.addEventListener('click', () => {
        if (darkMode) {
            body.style = 'background-color: rgb(255,255,255)';
            darkMode = false;
        } else {
            body.style = 'background-color: rgb(15,15,15)';
            darkMode = true;
        }
    })




    /* FUNCTIONS */
    async function getCat() {
        clearFeed()
        const res = await fetch('https://api.thecatapi.com/v1/images/search');
        const data = await res.json();
        let url = data[0].url
        let cat = new Cat(id, url, voteCount);
        id++;
        cats.push(cat);
        let currentcat = cats[cats.length - 1].url
        img.src = currentcat
        curr = cats.length - 1;
        votes.innerText = cats[curr].votes
        loadComments(cats[curr])
        return data;
    }
    getCat();

    function clearFeed() {
        let commentsArr = document.querySelectorAll('li');
        if (commentsArr) {
            for (let comment of commentsArr) {
                comment.remove();
            }
        }
    }

    function loadComments(cat) {
        clearFeed()
        let comments = cat.comments;
        if (comments.length) {
            for (let i = comments.length - 1; i >= 0; i--) {
                let comment = comments[i];
                commentsFeed.appendChild(comment)
            }
        }
    }







})
