class Letter {
    constructor(message) {
        this.message = message;
    }
}

module.exports = Letter;